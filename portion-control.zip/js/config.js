// Variables to be shared across scripts
var ss_config = {
    id: 'abonoihdcjidhkgiiopfphecgpkkkkka',
    firebaseUrl: 'https://sound-spy.firebaseio.com',
    // siteUrl: 'http://getsoundspy.com',
    siteUrl: 'http://localhost:3000',
    soundCloudAppId: 'b74dd64f32c066a42f13ed56d5d0e568'
};