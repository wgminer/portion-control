try {
    Typekit.load({ async: true });
} catch(e) {
    console.log(e);
}