var body = document.getElementsByTagName('body')[0];

var overlay = `<div id="portion-control"></div>`;

body.innerHTML += overlay;